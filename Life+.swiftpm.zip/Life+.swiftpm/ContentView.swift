import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationView {
                FirstAidGuidesView()
                    .navigationTitle("Offline First Aid Guides")
                    .preferredColorScheme(.dark)
            }
            .tabItem {
                Label("Guides", systemImage: "book")
            }
            
            NavigationView {
                MyProfileView()
                    .navigationTitle("My Profile")
                    .preferredColorScheme(.dark)
            }
            .tabItem {
                Label("Profile", systemImage: "person.crop.circle")
            }
            
        }
        .onAppear {
            UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
