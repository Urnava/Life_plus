import SwiftUI
import ContactsUI

struct MyProfileView: View {
    @State private var name = ""
    @State private var age = ""
    @State private var address = ""
    @State private var contactDetails = ""
    @State private var allergies = ""
    @State private var diseases = ""
    @State private var emergencyContacts: [EmergencyContact] = []
    @State private var isShowingEmergencyContactSheet = false
    @State private var isNameEditing = false
    
    var body: some View {
        NavigationView {
            VStack {
                Image(systemName: "person.circle")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 200, height: 200)
                    .clipShape(Circle())
                    .padding()
                
                Form {
                    Section(header: Text("Personal Information")) {
                        TextField("Name", text: $name, onEditingChanged: { editing in
                            isNameEditing = editing
                        })
                        .disableAutocorrection(true)
                        
                        TextField("Age", text: $age)
                        TextField("Address", text: $address)
                        TextField("Contact Details", text: $contactDetails)
                    }
                    
                    Section(header: Text("Health Information")) {
                        TextField("Allergies", text: $allergies)
                        TextField("Diseases", text: $diseases)
                    }
                    
                    Section(header: Text("Emergency Contacts")) {
                        ForEach(emergencyContacts, id: \.id) { contact in
                            EmergencyContactRow(contact: contact)
                        }
                        Button(action: {
                            isShowingEmergencyContactSheet.toggle()
                        }) {
                            Label("Add Emergency Contact", systemImage: "plus.circle.fill")
                        }
                        .sheet(isPresented: $isShowingEmergencyContactSheet) {
                            AddEmergencyContactView(isPresented: $isShowingEmergencyContactSheet, emergencyContacts: $emergencyContacts)
                        }
                    }
                }
                .navigationTitle("Profile")
            }
        }
    }
    
    struct EmergencyContactRow: View {
        let contact: EmergencyContact
        
        var body: some View {
            HStack {
                Text(contact.name)
                Spacer()
                Text(contact.phoneNumber)
                    .foregroundColor(.secondary)
            }
        }
    }
    
    struct EmergencyContact {
        let id = UUID()
        let name: String
        let phoneNumber: String
    }
    
    struct AddEmergencyContactView: View {
        @Binding var isPresented: Bool
        @Binding var emergencyContacts: [EmergencyContact]
        @State private var isContactPickerPresented = false
        
        var body: some View {
            VStack {
                Button(action: {
                    isContactPickerPresented.toggle()
                }) {
                    Text("Select Emergency Contacts")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .sheet(isPresented: $isContactPickerPresented) {
                    ContactPickerView(isPresented: $isContactPickerPresented, selectedContacts: $emergencyContacts)
                }
            }
            .navigationBarTitle("Select Emergency Contacts")
            .navigationBarItems(leading: Button("Cancel") {
                isPresented.toggle()
            })
        }
    }
    
    struct ContactPickerView: UIViewControllerRepresentable {
        @Binding var isPresented: Bool
        @Binding var selectedContacts: [EmergencyContact]
        
        func makeUIViewController(context: Context) -> CNContactPickerViewController {
            let picker = CNContactPickerViewController()
            picker.delegate = context.coordinator
            return picker
        }
        
        func updateUIViewController(_ uiViewController: CNContactPickerViewController, context: Context) {}
        
        func makeCoordinator() -> Coordinator {
            return Coordinator(parent: self)
        }
        
        class Coordinator: NSObject, CNContactPickerDelegate {
            let parent: ContactPickerView
            
            init(parent: ContactPickerView) {
                self.parent = parent
            }
            
            func contactPicker(_ picker: CNContactPickerViewController, didSelect contacts: [CNContact]) {
                for contact in contacts {
                    let name = "\(contact.givenName) \(contact.familyName)"
                    let phoneNumbers = contact.phoneNumbers.map { $0.value.stringValue }
                    for phoneNumber in phoneNumbers {
                        let emergencyContact = EmergencyContact(name: name, phoneNumber: phoneNumber)
                        parent.selectedContacts.append(emergencyContact)
                    }
                }
                parent.isPresented = false
            }
        }
    }
}

struct MyProfileView_Previews: PreviewProvider {
    static var previews: some View {
        MyProfileView()
    }
}
