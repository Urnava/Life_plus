    import SwiftUI
    import AVKit


    struct FirstAidGuide: Identifiable, Hashable {
        let id = UUID()
        let title: String
        let description: String
        
        func hash(into hasher: inout Hasher) {
            hasher.combine(id)
        }
    }


    struct SearchBar: View {
        @Binding var text: String
        
        var body: some View {
            HStack {
                TextField("Search", text: $text)
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                    .background(Color(.systemGray6))
                    .cornerRadius(8)
                    .padding(.horizontal)
                    .foregroundColor(.blue)
                    .accentColor(.blue)
            }
            .background(Color(.systemBackground))
        }
    }


    struct FirstAidGuidesView: View {
        let firstAidGuides: [FirstAidGuide] = [
            FirstAidGuide(title: "Cardiac Arrest", description: "Cardiac arrest is a sudden loss of heart function, often caused by an electrical disturbance in the heart. It can happen to anyone, anywhere, and at any time. When someone experiences cardiac arrest, they'll suddenly collapse, become unresponsive, and stop breathing or gasping. It's crucial to act quickly. Call emergency services immediately and start CPR (cardiopulmonary resuscitation) right away. Push hard and fast on the center of the chest, aiming for a rate of 100 to 120 compressions per minute, until help arrives or the person shows signs of life."),
            
            FirstAidGuide(title: "Burns", description: "Burns can be caused by heat, chemicals, electricity, or radiation. They vary in severity, from minor redness and pain to severe tissue damage. When providing first aid for burns, assess the extent of the injury. For minor burns, cool the affected area under running water for at least 10 to 20 minutes to stop the burning process and reduce pain. Do not use ice, as it can further damage the skin. Cover the burn with a sterile gauze bandage or clean cloth. For more severe burns, seek medical help immediately. Do not apply ointments, butter, or other home remedies, as they can trap heat and increase the risk of infection."),
            
           
            FirstAidGuide(title: "Heat Exhaustion", description: "Heat exhaustion is a heat-related illness caused by prolonged exposure to high temperatures and inadequate hydration. It can lead to dehydration, fatigue, weakness, dizziness, and nausea. If someone shows signs of heat exhaustion, move them to a cooler place and have them lie down. Loosen or remove tight clothing and apply cool, wet cloths to their skin or have them take a cool shower. Encourage them to drink fluids like water or sports drinks, but avoid caffeine or alcohol. If symptoms persist or worsen, seek medical attention."),
            
            FirstAidGuide(title: "Snake Bite", description: "Snake bites inject venom into the victim, which can lead to swelling, pain, tissue damage, and in severe cases, paralysis or death. If someone is bitten by a snake, keep them calm and still to slow the spread of venom. Remove tight clothing and jewelry near the bite site, as swelling may occur. Wash the bite with soap and water, and cover it with a clean, dry dressing. Immobilize the affected limb at or below the level of the heart and seek immediate medical attention. Do not apply ice or attempt to suck out the venom, as these methods are ineffective and may cause further harm."),
          
            FirstAidGuide(title: "Eye Injury", description: "Eye injuries can result from foreign objects, chemicals, or blunt trauma to the eye. Symptoms may include pain, redness, tearing, blurred vision, and sensitivity to light. If someone injures their eye, avoid rubbing or applying pressure to the affected eye, as this can cause further damage. Gently flush the eye with clean water or saline solution to remove debris or chemicals. Do not attempt to remove embedded objects or touch the eye. Cover the injured eye with a protective shield (e.g., paper cup) and seek medical attention immediately."),
            
            FirstAidGuide(title: "Electrocution", description: "Electrocution occurs when the body is exposed to an electric shock, which can cause burns, muscle contractions, cardiac arrest, or death. If you encounter someone who has been electrocuted, ensure your own safety first by turning off the power source or using a non-conductive object to move the person away from the electrical source. Check for responsiveness and breathing. If the person is unresponsive and not breathing, begin CPR immediately while waiting for emergency medical help. Do not touch the person if they are still in contact with the electrical source."),
            
            FirstAidGuide(title: "Bee Sting", description: "Bee stings can cause pain, swelling, redness, and itching at the site of the sting. In some cases, they can trigger a severe allergic reaction (anaphylaxis) characterized by difficulty breathing, swelling of the face or throat, and loss of consciousness. If someone is stung by a bee, remove the stinger as quickly as possible by scraping it out with a fingernail or a blunt object. Wash the affected area with soap and water, and apply a cold compress or ice pack to reduce swelling and pain. Monitor the person for signs of anaphylaxis, and seek emergency medical help if necessary."),
            
            FirstAidGuide(title: "Drowning", description: "Drowning occurs when a person's airway becomes blocked by water, preventing them from breathing. It's a leading cause of unintentional injury death worldwide. If you witness someone drowning, act quickly but safely. Call for help immediately and, if possible, throw a flotation device or reach out with a long object to pull the person to safety. Once out of the water, check for responsiveness and breathing. If the person is unresponsive and not breathing, start CPR immediately and continue until help arrives."),
            
            FirstAidGuide(title: "Hypothermia", description: "Hypothermia develops when the body loses heat faster than it can produce it, resulting in a dangerously low body temperature. It can occur in cold temperatures or cold water immersion. Symptoms include shivering, confusion, slurred speech, weak pulse, and loss of coordination. If you suspect someone has hypothermia, move them to a warm, dry place and remove wet clothing. Cover them with blankets or warm clothing and provide them with warm, non-alcoholic beverages. Seek medical help promptly, as severe hypothermia can be life-threatening."),
          
            FirstAidGuide(title: "Severe Bleeding", description: "Severe bleeding can result from trauma, injury, or medical conditions such as hemophilia or blood vessel disorders. It's important to control bleeding quickly to prevent shock and minimize blood loss. If someone is bleeding severely, apply direct pressure to the wound with a clean cloth or bandage. Elevate the injured limb above the level of the heart, if possible, to reduce blood flow. Use a pressure bandage or tourniquet if bleeding doesn't stop with direct pressure. Seek emergency medical help immediately.")
        ]

            @State private var searchText = ""
            @State private var selectedGuide: FirstAidGuide?
            @State private var showDetail = false
            
            var filteredGuides: [FirstAidGuide] {
                if searchText.isEmpty {
                    return firstAidGuides
                } else {
                    return firstAidGuides.filter { $0.title.localizedCaseInsensitiveContains(searchText) }
                }
            }
            
            var body: some View {
                VStack {
                    SearchBar(text: $searchText)
                        .padding()
                    
                    ScrollView {
                        LazyVGrid(columns: Array(repeating: GridItem(), count: 2), spacing: 16) {
                            ForEach(filteredGuides, id: \.self) { guide in
                                Button(action: {
                                    selectedGuide = guide
                                    showDetail = true
                                }) {
                                    VStack {
                                        Text(getEmoji(for: guide.title))
                                            .font(.largeTitle)
                                            .padding()
                                        Text(guide.title)
                                            .font(.headline)
                                            .padding(.bottom, 4)
                                        Text(guide.description.prefix(70) + "...")
                                            .font(.caption)
                                            .foregroundColor(.gray)
                                            .padding(.horizontal)
                                            .lineLimit(3)
                                    }
                                    .frame(width: 150, height: 200)
                                    .background(Color.blue.opacity(0.2))
                                    .cornerRadius(8)
                                }
                            }
                        }
                        .padding()
                    }
                }
                .sheet(isPresented: $showDetail) {
                    if let selectedGuide = selectedGuide {
                        VStack {
                            VideoPlayer(player: AVPlayer(url: Bundle.main.url(forResource: "cpr", withExtension: "mov")!))
                                .frame(height: 300)
                            Text(selectedGuide.description)
                                .padding()
                        }
                        .navigationTitle(selectedGuide.title)
                    }
                }
                .navigationTitle("First Aid Guides")
            }
            
            func getEmoji(for title: String) -> String {
                switch title {
                case "Cardiac Arrest":
                    return "❤️"
                case "Burns":
                    return "🔥"
                case "Heat Exhaustion":
                    return "☀️"
                case "Snake Bite":
                    return "🐍"
                case "Eye Injury":
                    return "👁️"
                case "Electrocution":
                    return "⚡"
                case "Bee Sting":
                    return "🐝"
                case "Drowning":
                    return "🌊"
                case "Hypothermia":
                    return "❄️"
                case "Severe Bleeding":
                    return "🩸"
                default:
                    return ""
                }
            }
        }


    struct FirstAidGuideDetailView: View {
        let firstAidGuide: FirstAidGuide
        
        var body: some View {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text(firstAidGuide.title)
                        .font(.title)
                        .foregroundColor(.green)
                        .padding()
                    
                    Text(firstAidGuide.description)
                        .padding()
                    
                    NavigationLink(destination: DemonstrationView()) {
                        Text("View Demonstration")
                            .font(.headline)
                            .foregroundColor(.blue)
                            .padding()
                    }
                }
                .padding()
            }
            .navigationTitle(firstAidGuide.title)
        }
    }


    struct DemonstrationView: View {
        var body: some View {
            VStack {
                VideoPlayer(player: AVPlayer(url: Bundle.main.url(forResource: "cpr", withExtension: "mov")!))
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                Spacer()
            }
            .navigationTitle("Demonstration")
        }
    }
