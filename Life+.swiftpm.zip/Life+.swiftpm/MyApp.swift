import SwiftUI

@main
struct LifePlusApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
